"""
structure.py

Structure-aware chunking for long documents.

Why this exists: extract.py's original chunker split purely on character
count and blind paragraph (\\n\\n) boundaries. That's safe but dumb — on a
400-page credit agreement (100+ pages of OCR text) it can just as easily
cut a definitions section or a covenant clause in half as not, and it has
no idea a "SCHEDULE A" or "ARTICLE VII" boundary even exists.

This module instead:
  1. Runs a cheap regex pass to find heading CANDIDATES with their offsets
     (extract_heading_candidates). This is fast and works even on messy
     OCR text; it's deliberately over-inclusive.
  2. Sends just that short candidate list (not the full document) to the
     LLM to confirm which are real section boundaries and label their type
     (get_document_structure). This keeps the LLM call small and reliable
     regardless of total document length.
  3. Uses the confirmed boundaries to split the document along real
     section lines (chunk_by_structure), merging small adjacent sections
     up to max_chars and falling back to paragraph-splitting only for any
     single section that is itself still too large.

If structure mapping fails for any reason (LLM error, no candidates found,
malformed response), callers should fall back to the older blind
paragraph-based chunker — this module never silently returns an empty or
wrong chunk list, it raises so the caller can decide.
"""

import re
import logging
from dataclasses import dataclass
from typing import List, Optional

from llm_client import LLMClient, safe_json_parse
from structure_prompts import STRUCTURE_MAPPING_SYSTEM_PROMPT, build_structure_mapping_prompt

logger = logging.getLogger("entity_extraction")

# Regex patterns for likely heading lines. Deliberately over-inclusive —
# the LLM pass filters false positives out afterward.
_HEADING_PATTERNS = [
    r"^\s*ARTICLE\s+[IVXLC\d]+.{0,80}$",
    r"^\s*SECTION\s+\d+(\.\d+)*.{0,80}$",
    r"^\s*SCHEDULE\s+[A-Z0-9]+.{0,80}$",
    r"^\s*EXHIBIT\s+[A-Z0-9]+.{0,80}$",
    r"^\s*[A-Z][A-Z0-9 ,\-'&]{6,70}$",  # short ALL-CAPS lines (likely headers)
]
_HEADING_RE = re.compile("|".join(f"(?:{p})" for p in _HEADING_PATTERNS), re.MULTILINE)

# A candidate repeated this many times or more is almost certainly a
# running header/footer, not a real section boundary — drop it before
# ever sending it to the LLM.
_REPEAT_THRESHOLD = 4


@dataclass
class SectionBoundary:
    offset: int
    title: str
    section_type: str


def extract_heading_candidates(text: str, max_candidates: int = 300) -> List[dict]:
    """
    Regex pass over the raw text. Returns a list of {"offset": int, "line": str}
    in document order, order of magnitude cheaper than an LLM pass and works
    on OCR noise. Lines that repeat many times (running headers/footers) are
    dropped automatically since they're never real section boundaries.
    """
    candidates = []
    for m in _HEADING_RE.finditer(text):
        line = m.group(0).strip()
        if not line:
            continue
        candidates.append({"offset": m.start(), "line": line})

    # Drop lines that repeat often (page headers/footers, running heads)
    from collections import Counter
    counts = Counter(c["line"] for c in candidates)
    candidates = [c for c in candidates if counts[c["line"]] < _REPEAT_THRESHOLD]

    if len(candidates) > max_candidates:
        logger.warning(
            f"{len(candidates)} heading candidates found, truncating to "
            f"{max_candidates} to keep the structure-mapping call small."
        )
        candidates = candidates[:max_candidates]

    return candidates


def get_document_structure(client: LLMClient, doc_name: str, text: str) -> List[SectionBoundary]:
    """
    Full structure-mapping pass: regex candidates -> LLM classification.
    Raises if candidates can't be found or the LLM response can't be
    matched back to them, so callers can fall back cleanly.
    """
    candidates = extract_heading_candidates(text)
    if not candidates:
        raise ValueError(f"{doc_name}: no heading candidates found for structure mapping")

    user_prompt = build_structure_mapping_prompt(doc_name, candidates)
    response = client.complete_with_retry(
        system_prompt=STRUCTURE_MAPPING_SYSTEM_PROMPT,
        user_prompt=user_prompt,
    )
    parsed = safe_json_parse(response.text)
    if not isinstance(parsed, list):
        raise ValueError(f"{doc_name}: structure mapping did not return a JSON array")

    valid_offsets = {c["offset"] for c in candidates}
    boundaries = []
    for item in parsed:
        if not item.get("is_real_boundary"):
            continue
        offset = item.get("offset")
        if offset not in valid_offsets:
            logger.warning(f"{doc_name}: structure mapping returned unknown offset {offset}, skipping")
            continue
        boundaries.append(SectionBoundary(
            offset=offset,
            title=item.get("title", ""),
            section_type=item.get("section_type", "other"),
        ))

    boundaries.sort(key=lambda b: b.offset)
    logger.info(f"{doc_name}: {len(boundaries)} confirmed section boundaries "
                f"out of {len(candidates)} candidates")
    return boundaries


def _split_oversized(text: str, max_chars: int) -> List[str]:
    """Paragraph-boundary fallback split for a single section still over max_chars."""
    if len(text) <= max_chars:
        return [text]
    chunks, current = [], ""
    for para in text.split("\n\n"):
        if len(current) + len(para) > max_chars and current:
            chunks.append(current)
            current = para
        else:
            current = current + "\n\n" + para if current else para
    if current:
        chunks.append(current)
    return chunks


def chunk_by_structure(text: str, boundaries: List[SectionBoundary],
                        max_chars: int = 40000) -> List[str]:
    """
    Splits text at confirmed section boundaries rather than blind paragraph
    counts, so a definitions section or covenant clause is never cut mid-way.
    Adjacent small sections are merged up to max_chars to avoid a flood of
    tiny LLM calls; any single section still over max_chars falls back to
    paragraph-boundary splitting internally.
    """
    if not boundaries:
        return _split_oversized(text, max_chars)

    # Build raw sections between consecutive boundaries (plus preamble before
    # the first boundary, if any).
    offsets = [b.offset for b in boundaries] + [len(text)]
    raw_sections = []
    if offsets[0] > 0:
        raw_sections.append(text[0:offsets[0]])
    for start, end in zip(offsets[:-1], offsets[1:]):
        raw_sections.append(text[start:end])

    # Merge small adjacent sections up to max_chars; split any oversized
    # section on its own.
    chunks: List[str] = []
    current = ""
    for section in raw_sections:
        if len(section) > max_chars:
            if current:
                chunks.append(current)
                current = ""
            chunks.extend(_split_oversized(section, max_chars))
            continue
        if len(current) + len(section) > max_chars and current:
            chunks.append(current)
            current = section
        else:
            current += section
    if current:
        chunks.append(current)

    return chunks


def chunk_document(client: Optional[LLMClient], doc_name: str, text: str,
                    max_chars: int = 40000) -> List[str]:
    """
    Main entry point extract.py should call. Tries structure-aware chunking
    first (if a client is available and the doc is long enough to need
    chunking at all); falls back to the older blind paragraph splitter on
    any failure, so a structure-mapping error never blocks extraction.
    """
    if len(text) <= max_chars:
        return [text]

    if client is None:
        logger.info(f"{doc_name}: no LLM client passed for structure mapping, "
                     f"using paragraph-boundary chunking")
        return _split_oversized(text, max_chars)

    try:
        boundaries = get_document_structure(client, doc_name, text)
        chunks = chunk_by_structure(text, boundaries, max_chars)
        logger.info(f"{doc_name}: structure-aware chunking produced {len(chunks)} chunks")
        return chunks
    except Exception as e:
        logger.warning(f"{doc_name}: structure-aware chunking failed ({e}), "
                        f"falling back to paragraph-boundary chunking")
        return _split_oversized(text, max_chars)
