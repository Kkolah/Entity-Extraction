"""
extract.py

Step 1: read every .txt file in a folder, call the (internal, PII-guardrailed)
LLM once per document with the open-ended extraction prompt, and collect
raw entities with provenance. No clustering/normalization happens here —
this step is deliberately "dumb and complete."
"""

import os
import glob
import logging
import json
from dataclasses import dataclass, asdict
from typing import List

from llm_client import LLMClient, safe_json_parse
from prompts import EXTRACTION_SYSTEM_PROMPT, build_extraction_user_prompt
from structure import chunk_document

logger = logging.getLogger("entity_extraction")


@dataclass
class RawEntity:
    document: str
    entity_type: str
    qualifiers: dict
    value: str
    source_text: str
    context: str


def load_documents(folder_path: str) -> dict:
    """Read every .txt file in folder_path. Returns {filename: text}."""
    paths = sorted(glob.glob(os.path.join(folder_path, "*.txt")))
    if not paths:
        raise FileNotFoundError(f"No .txt files found in {folder_path}")
    docs = {}
    for p in paths:
        with open(p, "r", encoding="utf-8", errors="replace") as f:
            docs[os.path.basename(p)] = f.read()
    logger.info(f"Loaded {len(docs)} documents from {folder_path}")
    return docs


def extract_from_document(client: LLMClient, doc_name: str, doc_text: str) -> List[RawEntity]:
    """
    Chunking is structure-aware (see structure.py): a regex pass finds
    heading candidates (ARTICLE/SECTION/SCHEDULE/etc.), the LLM confirms
    which are real section boundaries, and the document is split along
    those rather than blind paragraph counts. This matters most for very
    long documents (400+ pages / 100+ pages of OCR text) where a naive
    character-count split can cut a definitions section or covenant clause
    in half. Falls back to paragraph-boundary splitting automatically if
    structure mapping fails for any reason — see chunk_document().
    """
    entities: List[RawEntity] = []
    chunks = chunk_document(client, doc_name, doc_text)

    for i, chunk in enumerate(chunks):
        user_prompt = build_extraction_user_prompt(doc_name, chunk)
        try:
            response = client.complete_with_retry(
                system_prompt=EXTRACTION_SYSTEM_PROMPT,
                user_prompt=user_prompt,
            )
            parsed = safe_json_parse(response.text)
        except Exception as e:
            # Fail LOUD and keep going — an audit trail needs to know this
            # document had a failed chunk, not silently show zero entities.
            logger.error(f"Extraction failed for {doc_name} chunk {i}: {e}")
            entities.append(RawEntity(
                document=doc_name,
                entity_type="__EXTRACTION_ERROR__",
                qualifiers={"chunk_index": i},
                value="",
                source_text="",
                context=str(e),
            ))
            continue

        if not isinstance(parsed, list):
            logger.error(f"Unexpected non-list JSON for {doc_name} chunk {i}")
            continue

        for item in parsed:
            entities.append(RawEntity(
                document=doc_name,
                entity_type=item.get("entity_type", "").strip(),
                qualifiers=item.get("qualifiers", {}) or {},
                value=item.get("value", ""),
                source_text=item.get("source_text", ""),
                context=item.get("context", ""),
            ))

    logger.info(f"{doc_name}: extracted {len(entities)} raw entities")
    return entities


def extract_corpus(client: LLMClient, folder_path: str) -> List[RawEntity]:
    docs = load_documents(folder_path)
    all_entities: List[RawEntity] = []
    for doc_name, doc_text in docs.items():
        all_entities.extend(extract_from_document(client, doc_name, doc_text))
    return all_entities


def save_raw_entities(entities: List[RawEntity], out_path: str):
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump([asdict(e) for e in entities], f, indent=2)
    logger.info(f"Saved {len(entities)} raw entities to {out_path}")
