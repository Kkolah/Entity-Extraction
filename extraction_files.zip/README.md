# Credit Agreement Entity Extraction — Open-Ended Pipeline

## What this does

1. **Reads** every `.txt` file in a folder (your OCR output).
2. **Extracts** every plausible entity per document via your internal,
   PII-guardrailed LLM API — no fixed schema, with mandatory source-span
   provenance for audit.
3. **Normalizes** entity type labels into one consistent taxonomy, so
   "Interest Rate" stays "Interest Rate" whether it came from a 2006
   document or a 2019 one.
4. **Outputs** a flat table: `document, entity_type, entity_id, value,
   qualifiers, source_text`.

## Structure-aware chunking for very long documents

For documents that fit in one call, extraction runs directly. For long ones
(e.g. 400+ page agreements, 100+ pages of OCR text) `structure.py` splits
along real section boundaries instead of blind character counts:

1. A regex pass finds heading *candidates* (`ARTICLE II`, `SECTION 3.01`,
   `SCHEDULE A`, short ALL-CAPS lines, etc.) — cheap, works on noisy OCR,
   deliberately over-inclusive. Repeated running headers/footers are
   dropped automatically.
2. Only that short candidate list (not the full document) goes to the LLM,
   which confirms which are real boundaries and labels each with a section
   type (definitions, covenant, schedule, ...).
3. The document is split along the confirmed boundaries, merging small
   adjacent sections up to the chunk size limit, so a definitions section
   or covenant clause is never cut in half mid-chunk.

If structure mapping fails for any reason, it falls back automatically to
the older paragraph-boundary splitter — a failed structure-mapping call
never blocks extraction, it just chunks a bit dumber for that document.

## The "Interest Rate 2006 vs Interest Rate 2007" problem

Fixed at the source, not patched after the fact. The extraction prompt
(`prompts.py`) forces the model to separate:

- `entity_type` — the stable kind of thing ("Interest Rate")
- `qualifiers` — what distinguishes this instance (`{"year": "2006"}`)
- `value` — the actual number/date/name

So the year never gets baked into the type name in the first place.
`normalize.py` is a **safety net** for labels that are still inconsistent
despite that (e.g. "Interest Rate" vs "Applicable Interest Rate") — it
clusters near-duplicate labels and asks the model to pick one canonical
name per cluster.

## Before running

**You must wire `llm_client.py`** to your bank's internal API — this is the
only file with a placeholder. Everything else calls `LLMClient.complete()`
and never touches a provider directly, so this is the one choke point to
audit for the PII guardrails.

Optionally wire `get_embedding()` in `normalize.py` if your internal API
exposes embeddings — that gives you similarity-based clustering instead of
the string-similarity fallback, which is more robust for labels that are
semantically the same but worded very differently.

## Run it

```bash
pip install scikit-learn numpy  # optional, only needed for embedding clustering

python run_pipeline.py \
  --input_folder ./ocr_txt_docs \
  --endpoint https://your-internal-api/v1/complete \
  --api_key $INTERNAL_API_KEY \
  --out_csv entities.csv
```

## Outputs

- `raw_entities.json` — everything extracted, pre-normalization (audit trail)
- `taxonomy_map.json` — the raw-label → canonical-label mapping (review this!)
- `entities.csv` / `entities.json` — final table, one row per entity instance

## Recommended next step

Given your existing SQLite audit-trail pattern on the credit agreement
project, `entities.csv` is designed to load straight into a table — `entity_id`
is a stable UUID per row so you can join against a human-review table later
without re-running extraction.

Review `taxonomy_map.json` by hand at least once early on — this is where
you'll catch the model over-merging two genuinely different concepts into
one canonical label, which is the failure mode to watch for in the opposite
direction from the "1000 near-duplicate labels" problem.
