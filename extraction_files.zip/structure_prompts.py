"""
structure_prompts.py

Prompt for the structure-mapping pass used by structure.py.

Design note: for a 400-page / 100+ page-OCR document, we do NOT send the
full document text to the LLM just to find section boundaries — that's
slow, expensive, and itself subject to the same long-context recall
degradation we're trying to avoid in extraction. Instead structure.py does
a cheap regex pass first to surface heading CANDIDATES (lines that look
like "ARTICLE II", "Section 3.01", "SCHEDULE A", short ALL-CAPS lines,
etc.) with their character offsets. Only that short candidate list goes to
the LLM, which classifies which are real section boundaries (OCR noise
produces plenty of false positives) and assigns each a short section type.
"""

STRUCTURE_MAPPING_SYSTEM_PROMPT = """You are identifying the real section \
structure of a credit agreement from a list of CANDIDATE heading lines. \
These candidates were found by a regex pass over OCR'd text and include \
false positives (OCR artifacts, stray capitalized lines, page headers/\
footers repeated on every page, table fragments) mixed in with real \
section boundaries.

For each candidate, decide whether it is a REAL section/article/schedule \
boundary. If it is, assign it a short section_type from this set (or a \
similarly short label if none fit): "preamble", "definitions", \
"covenant", "representation", "conditions_precedent", "interest_and_fees", \
"events_of_default", "collateral", "schedule", "exhibit", "signature", \
"other".

Reject candidates that are page headers/footers repeated many times \
(e.g. the same short line appearing at regular intervals), running heads, \
or table-of-contents entries pointing at page numbers rather than the \
section itself.

Output ONLY a JSON array, no prose, no markdown fences. Each element:

{
  "offset": <the integer offset you were given for this candidate>,
  "is_real_boundary": true/false,
  "title": "...",
  "section_type": "..."
}

Include every candidate you were given, even the rejected ones (with \
is_real_boundary: false). Do not invent offsets not in the candidate list."""


def build_structure_mapping_prompt(doc_name: str, candidates: list) -> str:
    lines = "\n".join(
        f'offset={c["offset"]}: "{c["line"]}"' for c in candidates
    )
    return f"""Document: {doc_name}

Candidate heading lines found by regex, in document order:

{lines}

Classify each candidate per the instructions. Return only the JSON array. \
There are {len(candidates)} candidates — your output array must have \
exactly {len(candidates)} elements, one per candidate, in the same order."""
